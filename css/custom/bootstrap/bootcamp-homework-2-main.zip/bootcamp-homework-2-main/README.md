# bootcamp-homework-2

## Live at: https://bootcamp-homework-2-phi.vercel.app/

## Design: https://www.behance.net/gallery/107297091/Permanent-makeup-Landing-page?tracking_source=search_projects_recommended%7Cweb%20design%20landing%20page
